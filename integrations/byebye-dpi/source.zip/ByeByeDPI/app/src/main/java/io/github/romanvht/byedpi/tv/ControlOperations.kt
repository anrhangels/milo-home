package io.github.romanvht.byedpi.tv
import android.content.Context
import android.net.VpnService
import io.github.romanvht.byedpi.data.Mode
import io.github.romanvht.byedpi.services.ServiceManager
import io.github.romanvht.byedpi.utility.getPreferences
import kotlinx.coroutines.*

object ControlOperations {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    var busy = false
        private set
    fun request(context: Context, enabled: Boolean) {
        if (busy) return
        val app = context.applicationContext
        if (enabled && VpnService.prepare(app) != null) return
        busy = true
        ControlEvents.error = ""
        // Preserve the user's autostart option; a manual stop suppresses it until a successful start.
        if (!enabled) app.getPreferences().edit().putBoolean("tv_manual_off",true).apply()
        scope.launch {
            try {
                withTimeout(22_000) {
                    if (enabled) {
                        check(ServiceManager.waitStart(app,Mode.VPN)) { "Engine did not confirm startup" }
                        app.getPreferences().edit().putBoolean("tv_manual_off",false).apply()
                    } else ServiceManager.waitStop()
                }
            } catch (e: Exception) {
                ControlEvents.error = e.message ?: "Service operation failed"
            } finally {
                busy = false
                ControlEvents.changed()
            }
        }
    }
}
