package io.github.romanvht.byedpi.tv

/** Pure engine-state projection, also exercised without Android/native libraries. */
internal object ControlSnapshot {
    fun state(hasSession: Boolean, ready: Boolean, stopping: Boolean, failed: Boolean): Int = when {
        stopping && hasSession -> 3
        hasSession && ready -> 2
        hasSession -> 1
        failed -> 4
        else -> 0
    }
}
