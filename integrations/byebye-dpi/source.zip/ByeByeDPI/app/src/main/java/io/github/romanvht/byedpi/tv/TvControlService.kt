package io.github.romanvht.byedpi.tv
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.*
import io.github.romanvht.byedpi.services.ServiceManager

/** Version 1 protocol: 1=query/subscribe, 2=enable, 3=disable, 4=unsubscribe; 100=state. */
class TvControlService : Service() {
    private val clients = mutableMapOf<IBinder,Messenger>()
    private val notify: () -> Unit = { sendState() }
    private val endpoint = Messenger(Handler(Looper.getMainLooper()) { msg ->
        val uid = msg.sendingUid
        val allowed = ControlPolicy.allows(packageManager.getPackagesForUid(uid),
            packageManager.checkSignatures(uid,Process.myUid()) == PackageManager.SIGNATURE_MATCH)
        if (!allowed) return@Handler true
        val reply = msg.replyTo ?: return@Handler true
        if (msg.what == 4) { clients.remove(reply.binder); return@Handler true }
        if (msg.what !in 1..3) return@Handler true
        clients[reply.binder] = reply
        if (msg.what == 2 && VpnService.prepare(this) != null) {
            sendState(5)
        } else {
            if (msg.what == 2 || msg.what == 3) ControlOperations.request(this,msg.what == 2)
            sendState()
        }
        true
    })
    override fun onCreate() { super.onCreate(); ControlEvents.observers.add(notify) }
    override fun onBind(intent: Intent): IBinder = endpoint.binder
    override fun onDestroy() { ControlEvents.observers.remove(notify); clients.clear(); super.onDestroy() }
    private fun sendState(overrideState: Int? = null) {
        val (state,running) = ServiceManager.controlState(this)
        clients.toMap().forEach { (token,client) ->
            try {
                client.send(Message.obtain(null,100).apply { data = Bundle().apply {
                    putInt("version",1); putInt("state",overrideState ?: state)
                    putBoolean("running",running); putBoolean("busy",ControlOperations.busy)
                    putString("error",ControlEvents.error)
                } })
            } catch (_: RemoteException) { clients.remove(token) }
        }
    }
}
