package io.github.romanvht.byedpi.tv
import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
class VpnConsentActivity : Activity() {
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        if (callingPackage != "com.gathin.tvhome") { finish(); return }
        if (state == null) {
            val consent = VpnService.prepare(this)
            if (consent == null) complete(true) else startActivityForResult(consent,1)
        }
    }
    @Deprecated("Legacy API for Android TV 11")
    override fun onActivityResult(request: Int, result: Int, data: Intent?) {
        super.onActivityResult(request,result,data)
        if (request == 1) complete(result == RESULT_OK && VpnService.prepare(this) == null)
    }
    private fun complete(allowed: Boolean) {
        if (allowed) ControlOperations.request(this,true)
        setResult(if(allowed) RESULT_OK else RESULT_CANCELED); finish()
    }
}
