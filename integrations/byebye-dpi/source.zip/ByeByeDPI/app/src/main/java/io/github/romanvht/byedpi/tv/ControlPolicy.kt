package io.github.romanvht.byedpi.tv

internal object ControlPolicy {
    fun allows(packages: Array<String>?, matchingSignature: Boolean): Boolean =
        matchingSignature && packages?.contains("com.gathin.tvhome") == true

    fun autoStart(configured: Boolean, manuallyStopped: Boolean): Boolean =
        configured && !manuallyStopped
}
