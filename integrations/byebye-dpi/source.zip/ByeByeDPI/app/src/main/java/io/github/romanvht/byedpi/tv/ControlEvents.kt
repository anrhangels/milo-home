package io.github.romanvht.byedpi.tv

/** Main-thread only. Observers exist only while the network popup is bound. */
object ControlEvents {
    var error: String = ""
    val observers = mutableSetOf<() -> Unit>()
    fun changed() { observers.toList().forEach { it() } }
}
